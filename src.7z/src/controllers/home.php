<?php
echo view('home');