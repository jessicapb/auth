<?php
    $title="Login";
    echo view('login',['title'=>$title]);