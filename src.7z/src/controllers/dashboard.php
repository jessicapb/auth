<?php
$title = "Dashboard";
echo view('dashboard',['title'=>$title]);