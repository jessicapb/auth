<?php
$title = "Sign up";
echo view('register',['title'=>$title]);