INSERT INTO users (email, password)
VALUES (
    'test@test.com',
    '$2a$04$UtqUq/Vh1kuwXxkLEcSh9O2eZBaG3wzoylDVxstLs3rNJltS7DHhe'
  );